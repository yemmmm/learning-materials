# 本体与 Agent · v3.1 HTML 内容增强版

22 页：19 页主线与 OntoWeave 截图介绍，结尾 3 页恢复旧版全部 13 个 FAQ。每页增加定义、案例、图示、依据或建设说明。本轮以内容为主，版式先保持基本可读。

- 打开 `ontology-agent-slides-v3.1.html` 开始演示，单文件可离线使用。
- `ontology-agent-slides-v3.1.pdf` 是完整展开的静态阅读版。
- `ontology-agent-content-v3.1.md` 用于逐页审阅文字。
- `ontology-agent-speaker-notes-v3.1.md` 提供讲述提示和来源。

方向键或空格翻页；S 分步演讲，A 展开本页，G 目录，N 备注，F 全屏。E 开启正文编辑，Ctrl+S 下载修改后的 HTML。手机横屏更适合阅读。

第 17 页为用户提供的真实 OntoWeave 界面截图，点击可放大。审批政策对照、模型元素高亮、负责人变化、推导与矛盾、事实缺失均为本地教学演示，不调用真实业务系统。OWL 自动推理介绍通用能力，不代表平台当前已提供该功能。

按 Frontend Slides 技能的 HTML 方式制作，沿用此前暖白／深绿风格和封面素材。字体、图片、样式、交互、讲者备注全部内嵌。第三方许可见 THIRD-PARTY-NOTICES.txt。
