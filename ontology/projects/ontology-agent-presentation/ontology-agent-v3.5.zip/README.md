# 本体与 Agent · v3.5

22 页：19 页主线 + 3 页答疑附录，含 13 个 FAQ。

打开 ontology-agent-slides-v3.5.html，即可离线演示。
静态阅读使用 ontology-agent-slides-v3.5.pdf。
完整口述讲稿见 ontology-agent-speech-v3.5.md；speaker-notes 为相同内容的兼容入口。
逐页文字见 ontology-agent-content-v3.5.md，修订与检查见 ontology-agent-review-v3.5.md。

方向键／空格翻页，G 目录，N 讲稿，S 分步，A 展开本页，F 全屏。点击截图可放大。手机建议横屏。
E 开启正文编辑，Ctrl+S 下载修改后的 HTML；修改不会自动更新 PDF 和 Markdown。

P17 重绘架构并突出建模 Agent，P18 新增平台能力，P19 保留原始界面截图；技术速览调序、本体与知识图谱页重写及完整讲稿一并纳入。

字体和图片已嵌入 HTML。许可见 THIRD-PARTY-NOTICES.txt。
