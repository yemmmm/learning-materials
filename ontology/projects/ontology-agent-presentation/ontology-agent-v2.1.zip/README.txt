本体与 Agent v2.1
解压后打开 ontology-agent-slides-v2.1.html，可离线交互演示。PDF 和逐页演讲稿为同一冻结版本；resources 目录提供来源与案例材料。此版保留本轮进一步调整前的内容，P22 的七视角请优先在 HTML 中查看。
