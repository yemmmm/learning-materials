# 本体与 Agent · v3.4

22 页：19 页主线 + 3 页按需答疑附录，保留全部 13 个 FAQ。

- 打开 ontology-agent-slides-v3.4.html 开始离线演示。
- 静态阅读：ontology-agent-slides-v3.4.pdf。
- 内容审阅：ontology-agent-content-v3.4.md。
- 讲述提示与来源：ontology-agent-speaker-notes-v3.4.md。
- 合并依据与新旧页码：ontology-agent-review-v3.4.md。

本轮从 27 页合为 22 页。P04 三层区分之后立即接 P05 RDF/OWL；Agent 职责、复用价值和平台使用的重复说明已合并。P18 保留 OntoWeave 原截图；P20–P22 为 FAQ。

G 目录、N 备注、S 分步、A 展开本页、F 全屏。E 编辑正文，Ctrl+S 下载修改后的 HTML。手机建议横屏。图片、字体和交互均已内嵌；教学交互不连接业务系统。

制作使用 Frontend Slides 与 frontend-design 指导，沿用旧版视觉风格。许可见 THIRD-PARTY-NOTICES.txt。
