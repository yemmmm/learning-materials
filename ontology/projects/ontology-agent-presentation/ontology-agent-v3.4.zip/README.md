# 本体与 Agent · v3.4

22 页：19 页主线 + 3 页按需答疑附录，保留全部 13 个 FAQ。

- 离线演示：ontology-agent-slides-v3.4.html。
- 静态阅读：ontology-agent-slides-v3.4.pdf。
- 完整逐页演讲稿：ontology-agent-speech-v3.4.md。
- 内容审阅：ontology-agent-content-v3.4.md。
- 合并依据与新旧页码：ontology-agent-review-v3.4.md。

演讲稿采用面向观众的口吻，包含解释、案例、过渡与收束。正文约 6,100 字，按约 30 分钟准备；末尾 3 页 FAQ 按需使用，参考资料集中在稿末。原 speaker-notes 文件也同步为相同的完整讲稿。

G 目录、N 逐页讲稿、S 分步、A 展开本页、F 全屏。E 编辑正文，Ctrl+S 下载修改后的 HTML。手机建议横屏。图片、字体、讲稿和交互均已内嵌；教学交互不连接业务系统。

页面仍为 v3.4：P04 三层区分之后立即接 P05 RDF/OWL，P18 保留 OntoWeave 原截图，P20–P22 为 FAQ。

制作使用 Frontend Slides 与 frontend-design 指导，沿用旧版视觉风格。许可见 THIRD-PARTY-NOTICES.txt。
