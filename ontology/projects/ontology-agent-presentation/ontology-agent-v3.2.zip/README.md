# 本体与 Agent · v3.2

26 页；新增 P10–P13：符号主义与联结主义、专家系统、优缺点比较，以及在 Agent 中的互补。沿用暖白与森林绿风格，保留原有差旅案例、OntoWeave 截图和结尾 13 个 FAQ。

- ontology-agent-slides-v3.2.html：单文件离线演示，使用浏览器打开。
- ontology-agent-slides-v3.2.pdf：26 页静态版本，完整显示全部内容。
- ontology-agent-content-v3.2.md：逐页文字与对比表，便于审阅内容。
- ontology-agent-speaker-notes-v3.2.md：讲述提示与概念来源。

P10–P13 位于本体与知识图谱之后、Agent 体系之前。历史表述采用“神经网络是联结主义的核心代表”；用 MYCIN 和差旅规则解释专家系统。本体定位为符号主义的知识表示方式，结合部分说明学习能力、显式语义、外部事实与规则工具的分工。相关内容属于概念教学。

第 21 页是用户提供的实际 OntoWeave 模型浏览截图，可点击放大。第 24–26 页为 FAQ。全部字体、图片、图示、交互、备注已内嵌到 HTML。

方向键/空格翻页，G 目录，N 备注，S 分步，A 展开本页，F 全屏，E 编辑，Ctrl+S 下载修改后的 HTML。手机建议横屏。交互为本地教学示意；PDF 保留默认事实与完整 FAQ。编辑 HTML 不会自动修改 PDF 或 Markdown。

本版沿用 Frontend Slides 技能：https://github.com/zarazhangrui/frontend-slides/blob/main/SKILL.md
第三方许可见 THIRD-PARTY-NOTICES.txt。
