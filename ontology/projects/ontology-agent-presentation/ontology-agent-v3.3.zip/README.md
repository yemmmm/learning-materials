# 本体与 Agent · v3.3

27 页。P09 新增 SKOS、SWRL、OWL-S、SPARQL 速览，每项一句用途和一个差旅例子，不展开语法。保留此前两条 AI 路线、专家系统与 Agent 协作介绍；OntoWeave 截图在 P22，13 个 FAQ 位于 P25–P27。

- ontology-agent-slides-v3.3.html：单文件离线演示，使用浏览器打开。
- ontology-agent-slides-v3.3.pdf：27 页静态版本。
- ontology-agent-content-v3.3.md：逐页文字与表格，便于审阅。
- ontology-agent-speaker-notes-v3.3.md：讲述提示与 W3C 等原始来源。

方向键/空格翻页，G 目录，N 备注，S 分步，A 展开本页，F 全屏，E 编辑，Ctrl+S 下载修改后的 HTML。手机建议横屏。图片、字体、样式与交互均已内嵌，截图可点击放大；PDF 保留完整内容和 FAQ。编辑 HTML 不会自动修改 PDF 或 Markdown。

沿用 Frontend Slides 技能：https://github.com/zarazhangrui/frontend-slides/blob/main/SKILL.md
第三方许可见 THIRD-PARTY-NOTICES.txt。
