# 本体与 Agent · v3.0

18 页，建议讲述 25–30 分钟。

- PPTX：可编辑文字、关系图与流程图，内含讲者备注。
- PDF：可直接阅读和展示。
- speaker-notes：逐页讲述提示与来源。
- outline：已审阅的内容草稿。

沿用旧版暖白／深绿风格，复用封面关系网络素材。编辑 PPTX 时建议安装 Noto Sans CJK SC 与 Noto Serif CJK SC；PDF 内嵌字体。

案例、流程与读取结果为教学示意。OWL 推理介绍通用技术能力，OntoWeave 当前不提供该自动推理运行。
